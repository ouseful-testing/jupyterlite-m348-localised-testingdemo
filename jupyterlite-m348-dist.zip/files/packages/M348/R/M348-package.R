#' @details
#' Collection of datasets and functions for use when studying M348 Applied statistical modelling
#'
#' @keywords internal
"_PACKAGE"
#> [1] "_PACKAGE"

#' @alias m348

